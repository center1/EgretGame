<?php
echo '<strong>心心相印</strong>';